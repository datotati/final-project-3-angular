import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { RestaurantService } from '../../services/services';

@Component({
  selector: 'app-basket',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './basket.html',
})
export class BasketComponent implements OnInit {

  basketItems: any[] = [];

  constructor(
    private api: RestaurantService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadBasket();
  }

  private refreshWithDelay(): void {
    setTimeout(() => this.loadBasket(), 300);
  }

  loadBasket(): void {
    this.api.getBasket().subscribe({
      next: (res: any) => {
        this.basketItems = res || [];
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('API Error:', err);
        this.basketItems = [];
        this.cdr.detectChanges();
      }
    });
  }

  removeItem(item: any): void {
    const productId = item.product?.id || item.productId;
    if (!productId) return;

    this.basketItems = this.basketItems.filter(
      i => i.product?.id !== productId
    );
    this.cdr.detectChanges();

    this.api.deleteFromBasket(productId).subscribe({
      next: () => this.refreshWithDelay(),
      error: (err) => {
        alert('შეცდომა: ' + err.status);
        this.loadBasket();
      }
    });
  }

  clearBasket(): void {
    if (!confirm('დარწმუნებული ხართ?')) return;

    const ids = this.basketItems
      .map(item => item.product?.id)
      .filter(id => id);

    this.basketItems = [];
    this.cdr.detectChanges();

    let completed = 0;

    ids.forEach(id => {
      this.api.deleteFromBasket(id).subscribe({
        next: () => {
          completed++;
          if (completed === ids.length) {
            this.refreshWithDelay();
          }
        },
        error: () => this.loadBasket()
      });
    });
  }

  getTotalPrice(): number {
    return this.basketItems.reduce((sum, item) => {
      const price = item.product?.price || 0;
      const quantity = item.quantity || 1;
      return sum + (price * quantity);
    }, 0);
  }
}
