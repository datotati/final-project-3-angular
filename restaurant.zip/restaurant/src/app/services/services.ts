import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RestaurantService {
  constructor(private http: HttpClient) {}

  getProducts(): Observable<any> {
    return this.http.get('https://restaurant.stepprojects.ge/api/Products/GetAll');
  }

  addToBasket(item: any): Observable<any> {
    return this.http.post('https://restaurant.stepprojects.ge/api/Baskets/AddToBasket', item);
  }

  getBasket(): Observable<any> {
    return this.http.get('https://restaurant.stepprojects.ge/api/Baskets/GetAll');
  }
  getCategories(): Observable<any> {
    return this.http.get('https://restaurant.stepprojects.ge/api/Categories/GetAll');
  }

  deleteFromBasket(productId: number): Observable<any> {
    return this.http.delete(
      `https://restaurant.stepprojects.ge/api/Baskets/DeleteProduct/${productId}`,
    );
  }
}
