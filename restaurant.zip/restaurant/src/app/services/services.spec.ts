import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RestaurantService {
  private baseUrl = 'https://restaurant.stepprojects.ge/api';

  constructor(private http: HttpClient) {}

  getProducts(): Observable<any> {
    return this.http.get(`${this.baseUrl}/Products/GetAll`);
  }

  getBasket(): Observable<any> {
    return this.http.get(`${this.baseUrl}/Baskets/GetAll`);
  }

  deleteFromBasket(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/Baskets/DeleteProduct/${id}`);
  }
}
