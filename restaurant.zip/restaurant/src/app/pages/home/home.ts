import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import Swal from 'sweetalert2';
import { RestaurantService } from '../../services/services';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './home.html',
})
export class HomeComponent implements OnInit {
  products: any[] = [];
  filteredProducts: any[] = [];
  categories: any[] = [];
  isLoading = true;
  error: string | null = null;
  addingToBasket = new Set<number>();

  selectedCategory: number | null = null;
  maxPrice = 100;
  selectedSpiciness: number | null = null;
  vegetarianOnly = false;
  nutsOnly = false;

  constructor(
    private api: RestaurantService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadProducts();
    this.loadCategories();
  }

  loadProducts(): void {
    this.isLoading = true;
    this.error = null;

    this.api.getProducts().subscribe({
      next: (res: any) => {
        this.products = this.filteredProducts = res;
        this.isLoading = false;
        this.cdr.detectChanges();
      },
      error: (err: any) => {
        console.error('API შეცდომა:', err);
        this.error = 'მონაცემების ჩატვირთვა ვერ მოხერხდა.';
        this.isLoading = false;
        this.cdr.detectChanges();
      },
    });
  }

  loadCategories(): void {
    this.api.getCategories().subscribe({
      next: (res: any) => {
        this.categories = res;
        this.cdr.detectChanges();
      },
      error: (err: any) => console.error('კატეგორიების ჩატვირთვის შეცდომა:', err),
    });
  }

  applyFilters(): void {
    this.filteredProducts = this.products.filter(p =>
      (this.selectedCategory === null || p.categoryId === this.selectedCategory) &&
      p.price <= this.maxPrice &&
      (this.selectedSpiciness === null || p.spiciness === this.selectedSpiciness) &&
      (!this.vegetarianOnly || p.vegeterian) &&
      (!this.nutsOnly || p.nuts)
    );
    this.cdr.detectChanges();
  }

  resetFilters(): void {
    this.selectedCategory = null;
    this.maxPrice = 100;
    this.selectedSpiciness = null;
    this.vegetarianOnly = false;
    this.nutsOnly = false;
    this.filteredProducts = this.products;
    this.cdr.detectChanges();
  }

  addToBasketWithAlert(product: any): void {
    if (this.addingToBasket.has(product.id)) return;

    this.addingToBasket.add(product.id);

    this.api.addToBasket({ productId: product.id, quantity: 1 }).subscribe({
      next: (res: any) => {
        this.addingToBasket.delete(product.id);
        this.cdr.detectChanges();

        Swal.fire({
          title: 'წარმატება!',
          text: `${product.name} დაემატა კალათაში`,
          icon: 'success',
          confirmButtonText: 'OK'
        });
      },
      error: (err: any) => {
        console.error('დამატებისას მოხდა შეცდომა:', err);
        this.addingToBasket.delete(product.id);
        this.cdr.detectChanges();

        Swal.fire({
          title: 'შეცდომა!',
          text: 'პროდუქტის დამატება ვერ მოხერხდა!',
          icon: 'error',
          confirmButtonText: 'OK'
        });
      },
    });
  }
}