import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { RestaurantService } from '../../services/services';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterModule, CommonModule],
  templateUrl: './navbar.html',
})
export class NavbarComponent implements OnInit {

  basketCount: number = 0;

  constructor(
    private router: Router,
    private api: RestaurantService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadBasketCount();
  }

  loadBasketCount(): void {
    this.api.getBasket().subscribe({
      next: (res: any) => {
        this.basketCount = res.reduce(
          (sum: number, item: any) => sum + item.quantity,
          0
        );
        this.cdr.detectChanges();
      }
    });
  }

  goToBasket() {
    const currentUrl = this.router.url;

    if (currentUrl.startsWith('/basket')) {
      this.router.navigateByUrl('/basket', { skipLocationChange: true }).then(() => {
        this.router.navigate(['/basket']);
      });
    } else {
      this.router.navigate(['/basket']);
    }
  }
}