import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  standalone: true,
  template: ` <footer class="bg-dark text-white text-center py-3 mt-5">© IT STEP 2026</footer> `,
})
export class FooterComponent {}
