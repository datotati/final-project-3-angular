import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home';
import { BasketComponent } from './pages/basket/basket';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'basket', component: BasketComponent },
];
